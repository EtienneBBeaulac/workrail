import { z } from 'zod';
import type { ToolBuilder, ToolDefinition } from '../tool-factory.js';
import type { NotesWorkflowHandlers, WrappedToolHandler } from '../types/workflow-tool-edition.js';
import { buildV2ToolRegistry } from '../v2/tool-registry.js';
import { StartWorkInput, SubmitWorkInput, ResumeWorkInput, ReadEvidenceInput } from './contracts.js';
import { verifyCapability } from './capabilities.js';
import { startWork, submitWork, resumeWork, readEvidence } from './service.js';
import type { McpCallToolResult } from '../types/workflow-tool-edition.js';
const response = (value: unknown, isError = false): McpCallToolResult => ({ content: [{ type: 'text', text: JSON.stringify(value) }], ...(isError ? { isError: true } : {}) });
const invalid = () => response({ kind: 'invalid_reference', message: 'Use the reference returned for this operation.' }, true);
export function buildNotesToolRegistry(buildTool: ToolBuilder): {
    readonly tools: readonly ToolDefinition<z.ZodType>[];
    readonly handlers: NotesWorkflowHandlers;
} {
    const legacy = buildV2ToolRegistry(buildTool);
    // Scheduling only. Committed identity and replay always come from the engine log.
    // This prevents independent requests in one server being treated as reentrant locks.
    const pending = new Map<string, Promise<void>>();
    const submit: WrappedToolHandler = async (raw, ctx) => {
        if (!ctx.v2)
            return invalid();
        const address = z.object({ assignment: z.string() }).passthrough().safeParse(raw);
        if (!address.success)
            return invalid();
        const cap = verifyCapability(address.data.assignment, ctx.v2.tokenCodecPorts);
        if (cap.isErr() || cap.value.kind !== 'submit')
            return invalid();
        const previous = pending.get(cap.value.sessionId) ?? Promise.resolve();
        let release!: () => void;
        const done = new Promise<void>(resolve => { release = resolve; });
        pending.set(cap.value.sessionId, done);
        await previous;
        try {
            const result = await submitWork({ ...ctx, v2: ctx.v2 }, cap.value, raw);
            return result.match(value => response(value), error => response({ kind: 'error', ...error }, true));
        }
        finally {
            release();
            if (pending.get(cap.value.sessionId) === done)
                pending.delete(cap.value.sessionId);
        }
    };
    const handlers: NotesWorkflowHandlers = {
        list_workflows: legacy.handlers.list_workflows,
        inspect_workflow: legacy.handlers.inspect_workflow,
        start_work: async (raw, ctx) => {
            const input = StartWorkInput.safeParse(raw);
            if (!input.success || !ctx.v2)
                return response({ kind: 'invalid_input', message: 'Supply workflowId, workspacePath, and goal.' }, true);
            const result = await startWork({ ...ctx, v2: ctx.v2 }, input.data);
            return result.match(value => response(value), error => error.code === 'UNSUPPORTED_WORKFLOW' ? response({ kind: 'unsupported_workflow', message: error.message }) : response({ kind: 'error', ...error }, true));
        },
        submit_work: submit,
        resume_work: async (raw, ctx) => {
            const input = ResumeWorkInput.safeParse(raw);
            if (!input.success || !ctx.v2)
                return invalid();
            const cap = verifyCapability(input.data.run, ctx.v2.tokenCodecPorts);
            if (cap.isErr() || cap.value.kind !== 'run')
                return invalid();
            const result = await resumeWork({ ...ctx, v2: ctx.v2 }, cap.value);
            return result.match(value => response(value), error => response({ kind: 'error', ...error }, true));
        },
        read_evidence: async (raw, ctx) => {
            const input = ReadEvidenceInput.safeParse(raw);
            if (!input.success || !ctx.v2)
                return invalid();
            const cap = verifyCapability(input.data.evidenceRef, ctx.v2.tokenCodecPorts);
            if (cap.isErr() || cap.value.kind !== 'evidence')
                return invalid();
            const result = await readEvidence({ ...ctx, v2: ctx.v2 }, cap.value);
            return result.match(value => response(value), error => response({ kind: 'error', ...error }, true));
        },
    };
    const definitions = [
        {
            name: 'start_work', title: 'Start work', description: 'Start a linear notes workflow. Do the returned instruction, then submit_work with its assignment and result.notes.', inputSchema: StartWorkInput, annotations: { readOnlyHint: false, idempotentHint: false }
        },
        {
            name: 'submit_work', title: 'Submit work', description: 'Submit what you did as result.notes. On correct, follow problems and use the new assignment. Retry an interrupted call unchanged. On error, resume the run.', inputSchema: SubmitWorkInput, annotations: { readOnlyHint: false, idempotentHint: true }
        },
        {
            name: 'resume_work', title: 'Resume work', description: 'Read the current instruction or final outcome using the run reference. This does not advance work.', inputSchema: ResumeWorkInput, annotations: { readOnlyHint: true, idempotentHint: true }
        },
        {
            name: 'read_evidence', title: 'Read submitted evidence', description: 'Read the retained original arguments using a receipt evidence reference.', inputSchema: ReadEvidenceInput, annotations: { readOnlyHint: true, idempotentHint: true }
        },
    ];
    return { tools: [...legacy.tools.filter(t => t.name === 'list_workflows' || t.name === 'inspect_workflow'), ...definitions], handlers };
}
