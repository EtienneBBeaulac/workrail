import { z } from 'zod';
import { ok, err, type Result } from 'neverthrow';
import type { TokenVerifyPorts } from '../../v2/durable-core/tokens/token-codec-capabilities.js';
const identity = { sessionId: z.string().min(1), runId: z.string().min(1) };
const CapabilitySchema = z.discriminatedUnion('kind', [
    z.object({ kind: z.literal('run'), ...identity }).strict(),
    z.object({
        kind: z.literal('submit'), ...identity, nodeId: z.string().min(1), attemptId: z.string().min(1)
    }).strict(),
    z.object({
        kind: z.literal('evidence'), ...identity, attemptId: z.string().min(1)
    }).strict(),
]);
export type NotesCapability = z.infer<typeof CapabilitySchema>;
export type CapabilityError = {
    readonly code: 'INVALID_CAPABILITY';
    readonly message: string;
};
const invalid = (): CapabilityError => ({ code: 'INVALID_CAPABILITY', message: 'Use the reference returned by this tool for this operation.' });
const encoder = new TextEncoder();
const domain = 'workrail:notes-capability:v1:';
// The signed operation prevents a read reference from becoming submission authority.
// These tokens deliberately cannot be decoded by the legacy continuation codec.
export function signCapability(payload: NotesCapability, ports: TokenVerifyPorts): Result<string, CapabilityError> {
    const key = ports.base64url.decodeBase64Url(ports.keyring.current.keyBase64Url);
    if (key.isErr())
        return err(invalid());
    const encoded = ports.base64url.encodeBase64Url(encoder.encode(JSON.stringify(payload)));
    const signature = ports.hmac.hmacSha256(key.value, encoder.encode(domain + encoded));
    return ok(`wn1.${encoded}.${ports.base64url.encodeBase64Url(signature)}`);
}
export function verifyCapability(raw: string, ports: TokenVerifyPorts): Result<NotesCapability, CapabilityError> {
    if (raw.length > 4096)
        return err(invalid());
    const parts = raw.split('.');
    if (parts.length !== 3 || parts[0] !== 'wn1')
        return err(invalid());
    const signature = ports.base64url.decodeBase64Url(parts[2]!);
    const body = ports.base64url.decodeBase64Url(parts[1]!);
    if (signature.isErr() || signature.value.length !== 32 || body.isErr())
        return err(invalid());
    const valid = [ports.keyring.current, ports.keyring.previous].some(key => {
        if (!key)
            return false;
        const bytes = ports.base64url.decodeBase64Url(key.keyBase64Url);
        return bytes.isOk() && ports.hmac.timingSafeEqual(signature.value, ports.hmac.hmacSha256(bytes.value, encoder.encode(domain + parts[1]!)));
    });
    if (!valid)
        return err(invalid());
    try {
        const parsed = CapabilitySchema.safeParse(JSON.parse(new TextDecoder().decode(body.value)));
        return parsed.success ? ok(parsed.data) : err(invalid());
    }
    catch {
        return err(invalid());
    }
}
