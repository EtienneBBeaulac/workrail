import { z } from 'zod';
import { err, ok, type Result } from 'neverthrow';
import type { Workflow } from '../../types/workflow.js';
import type { StartWorkflowError } from '../../v2/usecases/start-workflow.js';
import { utf8ByteLength } from '../../v2/durable-core/schemas/lib/utf8-byte-length.js';
export const StartWorkInput = z.object({
    workflowId: z.string().min(1), workspacePath: z.string().min(1), goal: z.string().min(1)
}).strict();
export const SubmitWorkInput = z.object({
    assignment: z.string().min(1).max(4096),
    result: z.object({ notes: z.string().refine(s => s.trim().length > 0, 'Describe the work in nonblank notes.').refine(s => utf8ByteLength(s) <= 32768, 'Keep notes within 32 KiB of UTF-8 text.') }).strict(),
}).strict();
export const ResumeWorkInput = z.object({ run: z.string().min(1).max(4096) }).strict();
export const ReadEvidenceInput = z.object({ evidenceRef: z.string().min(1).max(4096) }).strict();
// Admission is deliberately closed: newly added workflow semantics need an
// explicit profile decision before they can silently change notes-only runs.
const NotesDefinition = z.object({
    id: z.string(), name: z.string(), description: z.string(), version: z.string(),
    steps: z.array(z.object({
        id: z.string(), title: z.string(), prompt: z.string(),
        guidance: z.array(z.string()).optional(), notesOptional: z.boolean().optional(),
        agentRole: z.string().optional(), modelTier: z.enum(['lightweight', 'mid', 'heavy']).optional(),
    }).strict()).min(1),
    metaGuidance: z.array(z.string()).optional(),
    modelTier: z.enum(['lightweight', 'mid', 'heavy']).optional(),
    about: z.string().optional(), examples: z.array(z.string()).optional(),
    validatedAgainstSpecVersion: z.number().optional(),
    metricsProfile: z.literal('none').optional(),
}).strict();
export function admitNotesWorkflow(workflow: Workflow): Result<void, StartWorkflowError> {
    const result = NotesDefinition.safeParse(workflow.definition);
    return result.success ? ok(undefined) : err({ kind: 'precondition_failed', message: 'unsupported_workflow: This profile supports linear text steps only. Structured contracts, context-dependent execution, gates, and delegation require another profile.' });
}
export type Receipt = {
    readonly attemptId: string;
    readonly evidence: string;
};
export type WorkProgress = {
    readonly kind: 'work';
    readonly run: string;
    readonly assignment: string;
    readonly instruction: string;
} | {
    readonly kind: 'correct';
    readonly run: string;
    readonly assignment: string;
    readonly instruction: string;
    readonly attempt: Receipt;
    readonly problems: readonly string[];
} | {
    readonly kind: 'finished';
    readonly run: string;
    readonly outcome: {
        readonly kind: 'completed';
        readonly retained: readonly Receipt[];
    } | {
        readonly kind: 'incomplete';
        readonly reason: string;
        readonly retained: readonly Receipt[];
    };
};
export type NotesResponse = WorkProgress | {
    readonly kind: 'replay_conflict';
    readonly original: Receipt;
    readonly current: WorkProgress;
} | {
    readonly kind: 'not_retained';
    readonly reason: string;
};
