import { z } from 'zod';
import { ok, err, ResultAsync, type Result } from 'neverthrow';
import type { V2ToolContext } from '../types.js';
import type { NotesCapability } from './capabilities.js';
import { signCapability } from './capabilities.js';
import { admitNotesWorkflow, SubmitWorkInput, type NotesResponse, type WorkProgress, type Receipt } from './contracts.js';
import { executeStartWorkflow } from '../../v2/usecases/start-workflow.js';
import { asSessionId, asRunId, asNodeId, asAttemptId } from '../../v2/durable-core/ids/index.js';
import { asSortedEventLog } from '../../v2/durable-core/sorted-event-log.js';
import { buildSessionIndex, type SessionIndex } from '../../v2/durable-core/session-index.js';
import type { LoadedSessionTruthV2 } from '../../v2/ports/session-event-log-store.port.js';
import type { DomainEventV1 } from '../../v2/durable-core/schemas/session/index.js';
import type { NativeSubmissionV1 } from '../../v2/durable-core/schemas/session/events.js';
import { toCanonicalBytes } from '../../v2/durable-core/canonical/jcs.js';
import { JsonValueSchema } from '../../v2/durable-core/canonical/json-zod.js';
import { deriveChildAttemptId } from '../../v2/durable-core/ids/attempt-id-derivation.js';
import { derivePendingStep } from '../../v2/durable-core/projections/snapshot-state.js';
import { renderPendingPrompt } from '../../v2/durable-core/domain/prompt-renderer.js';
import { hasWorkflowDefinitionShape } from '../../types/workflow-definition.js';
import { getCachedWorkflow } from '../../v2/usecases/workflow-object-cache.js';
import { advanceAndRecord } from '../handlers/v2-execution/advance.js';
import { buildAndAppendPlan } from '../handlers/v2-advance-core/event-builders.js';
import { buildBlockedNodeSnapshot } from '../../v2/durable-core/domain/blocked-node-builder.js';
import type { ExecutionSnapshotFileV1 } from '../../v2/durable-core/schemas/execution-snapshot/index.js';
import type { WithHealthySessionLock } from '../../v2/durable-core/ids/with-healthy-session-lock.js';
import { NullGitSnapshotV2 } from '../../v2/ports/git-snapshot.port.js';
type RunIdentity = Pick<NotesCapability, 'sessionId' | 'runId'>;
type Submission = Extract<NotesCapability, {
    kind: 'submit';
}>;
type AdvanceEvent = Extract<DomainEventV1, {
    kind: 'advance_recorded';
}>;
type NodeEvent = Extract<DomainEventV1, {
    kind: 'node_created';
}>;
export type NotesError = {
    readonly code: 'UNSUPPORTED_WORKFLOW' | 'INVALID_REFERENCE' | 'STORAGE_ERROR';
    readonly message: string;
};
const failure = (message: string): NotesError => ({ code: 'STORAGE_ERROR', message });
const invalid = (): NotesError => ({ code: 'INVALID_REFERENCE', message: 'Reference does not identify the current notes-profile run.' });
const io = (): NotesError => failure('Could not confirm durable state. Retry the same call or resume this run; do not change its submitted answer.');
async function load(ctx: V2ToolContext, identity: RunIdentity): Promise<Result<{
    truth: LoadedSessionTruthV2;
    index: SessionIndex;
    latest: NodeEvent;
}, NotesError>> {
    const loaded = await ctx.v2.sessionStore.load(asSessionId(identity.sessionId));
    if (loaded.isErr())
        return err(io());
    const sorted = asSortedEventLog(loaded.value.events);
    if (sorted.isErr())
        return err(io());
    const index = buildSessionIndex(sorted.value);
    const run = index.runStartedByRunId.get(identity.runId);
    if (!run || run.data.agentProfile !== 'notes-v1')
        return err(invalid());
    const nodes = loaded.value.events.filter((e): e is NodeEvent => e.kind === 'node_created' && e.scope.runId === identity.runId);
    const latest = nodes.at(-1);
    if (!latest)
        return err(invalid());
    return ok({
        truth: loaded.value, index, latest
    });
}
function receipt(ctx: V2ToolContext, identity: RunIdentity, attemptId: string): Result<Receipt, NotesError> {
    return signCapability({
        kind: 'evidence', sessionId: identity.sessionId, runId: identity.runId, attemptId
    }, ctx.v2.tokenCodecPorts)
        .map(evidence => ({ attemptId, evidence })).mapErr(() => io());
}
// Both fresh responses and replay are projections of the same committed node.
async function project(ctx: V2ToolContext, identity: RunIdentity, state: {
    truth: LoadedSessionTruthV2;
    index: SessionIndex;
    latest: NodeEvent;
}, node = state.latest): Promise<Result<WorkProgress, NotesError>> {
    const snap = await ctx.v2.snapshotStore.getExecutionSnapshotV1(node.data.snapshotRef);
    if (snap.isErr() || !snap.value)
        return err(io());
    const engine = snap.value.enginePayload.engineState;
    const run = signCapability({
        kind: 'run', sessionId: identity.sessionId, runId: identity.runId
    }, ctx.v2.tokenCodecPorts);
    if (run.isErr())
        return err(io());
    const advances = state.truth.events.filter((e): e is AdvanceEvent => e.kind === 'advance_recorded' && e.scope.runId === identity.runId && !!e.data.submission);
    const incoming = advances.find(e => e.data.outcome.kind === 'advanced' && e.data.outcome.toNodeId === node.scope.nodeId);
    if (engine.kind === 'complete' || (engine.kind === 'blocked' && engine.blocked.kind === 'terminal_block')) {
        // Completion ends mutation authority, not access to retained work. Include
        // earlier accepted steps as well as rejections, even for incomplete runs.
        const retained: Receipt[] = [];
        for (const advance of advances) {
            const ref = receipt(ctx, identity, advance.data.attemptId);
            if (ref.isErr()) return err(ref.error);
            retained.push(ref.value);
        }
        const outcome = engine.kind === 'complete'
            ? {kind: 'completed' as const, retained}
            : {kind: 'incomplete' as const, reason: engine.blocked.reason.kind, retained};
        return ok({kind: 'finished', run: run.value, outcome});
    }
    const pending = derivePendingStep(engine);
    if (!pending)
        return err(io());
    const pinned = await ctx.v2.pinnedStore.get(node.data.workflowHash);
    if (pinned.isErr() || !pinned.value || pinned.value.sourceKind !== 'v1_pinned' || !hasWorkflowDefinitionShape(pinned.value.definition))
        return err(io());
    const workflow = getCachedWorkflow(node.data.workflowHash, pinned.value.definition);
    const rendered = renderPendingPrompt({
        workflow, stepId: String(pending.stepId), loopPath: pending.loopPath, truth: state.truth, runId: asRunId(identity.runId), nodeId: asNodeId(node.scope.nodeId), rehydrateOnly: true, precomputedIndex: state.index, cleanResponseFormat: true
    });
    if (rendered.isErr())
        return err(io());
    const nextAttempt = engine.kind === 'blocked' && engine.blocked.kind === 'retryable_block'
        ? ok(asAttemptId(engine.blocked.retryAttemptId))
        : deriveChildAttemptId(asAttemptId(incoming?.data.attemptId ?? node.scope.nodeId), ctx.v2.sha256);
    if (nextAttempt.isErr())
        return err(io());
    const assignment = signCapability({
        kind: 'submit', sessionId: identity.sessionId, runId: identity.runId, nodeId: node.scope.nodeId, attemptId: String(nextAttempt.value)
    }, ctx.v2.tokenCodecPorts);
    if (assignment.isErr())
        return err(io());
    const base = {
        run: run.value, assignment: assignment.value, instruction: rendered.value.prompt
    };
    if (engine.kind === 'blocked') {
        if (!incoming)
            return err(io());
        const attempt = receipt(ctx, identity, incoming.data.attemptId);
        if (attempt.isErr())
            return err(attempt.error);
        return ok({
            kind: 'correct', ...base, attempt: attempt.value, problems: engine.blocked.blockers.blockers.map(b => b.message)
        });
    }
    return ok({ kind: 'work', ...base });
}
export async function startWork(ctx: V2ToolContext, input: {
    workflowId: string;
    workspacePath: string;
    goal: string;
}): Promise<Result<NotesResponse, NotesError>> {
    const started = await executeStartWorkflow({
        ...ctx.v2, admission: { kind: 'notes-v1', validate: admitNotesWorkflow },
        fallbackWorkflowReader: ctx.workflowService, featureFlags: ctx.featureFlags,
    }, { ...input, injectOnboarding: false }, { triggerSource: 'mcp' });
    if (started.isErr())
        return err(started.error.kind === 'precondition_failed' && started.error.message.startsWith('unsupported_workflow')
            ? { code: 'UNSUPPORTED_WORKFLOW', message: started.error.message } : io());
    const identity = { sessionId: String(started.value.sessionId), runId: String(started.value.runId) };
    const state = await load(ctx, identity);
    return state.isErr() ? err(state.error) : project(ctx, identity, state.value);
}
export async function resumeWork(ctx: V2ToolContext, identity: RunIdentity): Promise<Result<NotesResponse, NotesError>> {
    const state = await load(ctx, identity);
    return state.isErr() ? err(state.error) : project(ctx, identity, state.value);
}
export async function readEvidence(ctx: V2ToolContext, identity: Extract<NotesCapability, {
    kind: 'evidence';
}>): Promise<Result<{
    readonly arguments: unknown;
}, NotesError>> {
    const state = await load(ctx, identity);
    if (state.isErr())
        return err(state.error);
    const event = state.value.truth.events.find((e): e is AdvanceEvent => e.kind === 'advance_recorded' && e.scope.runId === identity.runId && e.data.attemptId === identity.attemptId);
    if (!event?.data.submission)
        return err(invalid());
    // The event schema bounds the string; JSON parsing remains a storage boundary.
    try {
        return ok({ arguments: JSON.parse(event.data.submission.canonicalArguments) });
    }
    catch {
        return err(io());
    }
}
async function rejectSubmission(ctx: V2ToolContext, cap: Submission, state: {
    truth: LoadedSessionTruthV2;
    index: SessionIndex;
    latest: NodeEvent;
}, lock: WithHealthySessionLock, submission: NativeSubmissionV1, problems: readonly string[]): Promise<Result<void, NotesError>> {
    const snap = await ctx.v2.snapshotStore.getExecutionSnapshotV1(state.latest.data.snapshotRef);
    if (snap.isErr() || !snap.value)
        return err(io());
    const blockers = { blockers: [{
                code: 'INVALID_REQUIRED_OUTPUT' as const, pointer: { kind: 'output_contract' as const, contractRef: 'wr.notes.v1' }, message: problems.join(' ').slice(0, 500)
            }] };
    const blocked = buildBlockedNodeSnapshot({
        priorSnapshot: snap.value, primaryReason: { kind: 'invalid_required_output', contractRef: 'wr.notes.v1' }, attemptId: asAttemptId(cap.attemptId), blockers, sha256: ctx.v2.sha256
    });
    if (blocked.isErr())
        return err(io());
    let depth = 1;
    let cursor: NodeEvent | undefined = state.latest;
    while (cursor?.data.nodeKind === 'blocked_attempt') {
        depth++;
        cursor = cursor.data.parentNodeId ? state.index.nodeCreatedByNodeId.get(cursor.data.parentNodeId) : undefined;
    }
    const blockedState = blocked.value.enginePayload.engineState;
    if (blockedState.kind !== 'blocked')
        return err(io());
    const snapshot: ExecutionSnapshotFileV1 = depth < 3 ? blocked.value : {
        ...blocked.value,
        enginePayload: { ...blocked.value.enginePayload, engineState: {
                ...blockedState,
                blocked: {
                    kind: 'terminal_block', reason: { kind: 'submission_budget_exhausted' }, blockers
                },
            } },
    };
    const saved = await ctx.v2.snapshotStore.putExecutionSnapshotV1(snapshot);
    if (saved.isErr())
        return err(io());
    const appended = await buildAndAppendPlan({
        kind: 'blocked', truth: state.truth, lockedIndex: state.index, sessionId: asSessionId(cap.sessionId), runId: asRunId(cap.runId), currentNodeId: asNodeId(cap.nodeId), attemptId: asAttemptId(cap.attemptId), workflowHash: state.latest.data.workflowHash, submission, extraEventsToAppend: [], blockers, snapshotRef: saved.value, sessionStore: ctx.v2.sessionStore, idFactory: ctx.v2.idFactory, lock
    });
    return appended.mapErr(() => io());
}
async function submitLocked(ctx: V2ToolContext, cap: Submission, raw: unknown, submission: NativeSubmissionV1, lock: WithHealthySessionLock): Promise<Result<NotesResponse, NotesError>> {
    const state = await load(ctx, cap);
    if (state.isErr())
        return err(state.error);
    const { truth, index, latest } = state.value;
    const dedupeKey = `advance_recorded:${cap.sessionId}:${cap.nodeId}:${cap.attemptId}`;
    const recorded = index.advanceRecordedByDedupeKey.get(dedupeKey);
    if (recorded) {
        if (recorded.scope.runId !== cap.runId || !recorded.data.submission || recorded.data.outcome.kind !== 'advanced')
            return err(invalid());
        const target = index.nodeCreatedByNodeId.get(recorded.data.outcome.toNodeId);
        if (!target)
            return err(io());
        if (recorded.data.submission.digest === submission.digest) {
            // Historical replay must not incorporate notes from later submissions.
            const next = truth.events.find(e => e.kind === 'advance_recorded' && e.eventIndex > recorded.eventIndex);
            const prefix = { ...truth, events: truth.events.filter(e => !next || e.eventIndex < next.eventIndex) };
            const sorted = asSortedEventLog(prefix.events);
            if (sorted.isErr())
                return err(io());
            return project(ctx, cap, {
                truth: prefix, index: buildSessionIndex(sorted.value), latest: target
            });
        }
        const original = receipt(ctx, cap, recorded.data.attemptId);
        if (original.isErr())
            return err(original.error);
        const current = await project(ctx, cap, state.value);
        return current.isErr() ? err(current.error) : ok({
            kind: 'replay_conflict', original: original.value, current: current.value
        });
    }
    if (latest.scope.nodeId !== cap.nodeId)
        return err(invalid());
    const current = await project(ctx, cap, state.value);
    if (current.isErr())
        return err(current.error);
    if (current.value.kind !== 'work' && current.value.kind !== 'correct')
        return err(invalid());
    // Compare signed identity by deriving it from state, not by trusting caller IDs.
    const expected = signCapability(cap, ctx.v2.tokenCodecPorts);
    if (expected.isErr() || expected.value !== current.value.assignment)
        return err(invalid());
    const validation = SubmitWorkInput.safeParse(raw);
    if (!validation.success) {
        const rejected = await rejectSubmission(ctx, cap, state.value, lock, submission, validation.error.issues.slice(0, 4).map(issue => issue.code === 'custom' ? issue.message : issue.code === 'unrecognized_keys' ? 'Only assignment and result.notes are supported.' : 'Supply result.notes as text.'));
        if (rejected.isErr())
            return err(rejected.error);
    }
    else {
        const pinned = await ctx.v2.pinnedStore.get(latest.data.workflowHash);
        if (pinned.isErr() || !pinned.value || pinned.value.sourceKind !== 'v1_pinned' || !hasWorkflowDefinitionShape(pinned.value.definition))
            return err(io());
        const advanced = await advanceAndRecord({
            truth, sessionId: asSessionId(cap.sessionId), runId: asRunId(cap.runId), nodeId: asNodeId(cap.nodeId), attemptId: asAttemptId(cap.attemptId), workflowHash: latest.data.workflowHash, dedupeKey, inputContext: undefined, inputOutput: { notesMarkdown: validation.data.result.notes }, submission, lock, pinnedWorkflow: getCachedWorkflow(latest.data.workflowHash, pinned.value.definition), snapshotStore: ctx.v2.snapshotStore, sessionStore: ctx.v2.sessionStore, sha256: ctx.v2.sha256, idFactory: ctx.v2.idFactory, gitSnapshot: ctx.v2.gitSnapshot ?? new NullGitSnapshotV2(), lockedIndex: index
        });
        if (advanced.isErr())
            return err(io());
    }
    const committed = await load(ctx, cap);
    return committed.isErr() ? err(committed.error) : project(ctx, cap, committed.value);
}
export async function submitWork(ctx: V2ToolContext, cap: Submission, raw: unknown): Promise<Result<NotesResponse, NotesError>> {
    const json = JsonValueSchema.safeParse(raw);
    if (!json.success)
        return ok({ kind: 'not_retained', reason: 'Arguments must be JSON.' });
    const canonical = toCanonicalBytes(json.data as import('../../v2/durable-core/canonical/json-types.js').JsonValue);
    if (canonical.isErr() || canonical.value.length > 65536)
        return ok({ kind: 'not_retained', reason: 'Arguments exceed the 64 KiB capture limit.' });
    const submission: NativeSubmissionV1 = { digest: String(ctx.v2.sha256.sha256(canonical.value)).replace(/^sha256:/, ''), canonicalArguments: new TextDecoder().decode(canonical.value) };
    return ctx.v2.gate.withHealthySessionLock(asSessionId(cap.sessionId), lock => ResultAsync.fromSafePromise(submitLocked(ctx, cap, raw, submission, lock)).andThen(result => result)).mapErr(() => io());
}
