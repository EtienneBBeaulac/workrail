/**
 * Self-contained LLM agent loop for the WorkRail daemon.
 *
 * WHY this module exists: @mariozechner/pi-agent-core is a private npm package --
 * anyone outside Zillow gets a module-not-found crash on npm install. This module
 * replaces pi-agent-core's Agent class with a first-party implementation that
 * uses only public packages (@anthropic-ai/sdk, @anthropic-ai/bedrock-sdk).
 *
 * Design decisions:
 * - AgentClientInterface is a duck-typed injectable: both new Anthropic({ apiKey })
 *   and new AnthropicBedrock() satisfy it without any adapter shim. This follows
 *   the DI-for-boundaries principle from CLAUDE.md.
 * - Tool schemas are plain JSON Schema objects (Record<string, unknown>). The
 *   Anthropic SDK accepts raw JSON Schema for tool input_schema -- no TypeBox needed.
 * - steer() is queue-based, drained after each tool batch (before the next LLM call).
 *   This matches pi-agent-core's turn_end semantics exactly.
 * - AbortController is used internally so abort() cancels in-flight API calls.
 * - Unknown tool names return an error tool_result (is_error: true) and the loop
 *   continues rather than crashing -- LLMs occasionally hallucinate tool names.
 * - Tool throws are caught inside _executeTools() and returned as isError tool_results
 *   so the LLM can see what went wrong and decide how to recover. prompt() never throws
 *   due to a tool error -- only LLM API errors propagate to the caller.
 */

import type Anthropic from '@anthropic-ai/sdk';

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/**
 * Injectable LLM client interface.
 *
 * Both new Anthropic({ apiKey }) from @anthropic-ai/sdk and
 * new AnthropicBedrock() from @anthropic-ai/bedrock-sdk satisfy this interface.
 *
 * WHY duck-typed: avoids importing concrete SDK types in the interface definition,
 * keeping this module decoupled from specific SDK versions.
 */
export interface AgentClientInterface {
  messages: {
    create(
      params: Anthropic.MessageCreateParamsNonStreaming,
      options?: { signal?: AbortSignal },
    ): Promise<Anthropic.Message>;
  };
}

/**
 * Result returned by a tool's execute() function.
 *
 * WHY tools return content array: matches the Anthropic messages API format
 * for tool_result blocks, which accept an array of content blocks.
 */
export interface AgentToolResult<T> {
  readonly content: ReadonlyArray<{ readonly type: 'text'; readonly text: string }>;
  readonly details: T;
}

/**
 * Tool definition used by AgentLoop.
 *
 * WHY inputSchema uses Record<string, unknown>: the Anthropic SDK's Tool.input_schema
 * accepts raw JSON Schema as Record<string, unknown> -- no TypeBox needed.
 *
 * WHY execute() throws are caught at the call site: tool failures (e.g. bash exit code 1)
 * are recoverable -- the LLM must see the error to decide whether to retry, rephrase,
 * or escalate. AgentLoop._executeTools() catches throws and converts them to isError
 * tool_results so the session continues rather than dying.
 */
export interface AgentTool {
  readonly name: string;
  readonly description: string;
  /**
   * JSON Schema for the tool's input parameters.
   * Must be a valid JSON Schema object (type: 'object', properties: {...}).
   */
  readonly inputSchema: Record<string, unknown>;
  /** Human-readable label for logging. */
  readonly label: string;
  /**
   * Execute the tool call.
   * May throw on failure -- AgentLoop._executeTools() catches throws and converts them
   * to isError tool_results so the LLM can see and recover from failures.
   * Tools that do not use signal should name it _signal (underscore = intentional non-use).
   */
  execute(toolCallId: string, params: Record<string, unknown>, signal: AbortSignal): Promise<AgentToolResult<unknown>>;
}

/**
 * Events emitted by AgentLoop.
 *
 * Only the events used by workflow-runner.ts are defined here (YAGNI).
 * Additional events can be added additively when needed.
 *
 * turn_end: fired after tool results are collected and appended, BEFORE the next
 *   LLM call. Subscribers may call steer() here to inject a message before the
 *   next turn. All subscribers are awaited before the steer queue is checked.
 *
 * agent_end: fired when the loop exits (end_turn with empty steer queue, or error/abort).
 */
export type AgentEvent =
  | { readonly type: 'turn_end'; readonly toolResults: ReadonlyArray<AgentToolCallResult> }
  | { readonly type: 'agent_end' };

/** Internal representation of a completed tool call (for turn_end event). */
export interface AgentToolCallResult {
  readonly toolCallId: string;
  readonly toolName: string;
  readonly result: AgentToolResult<unknown> | null;
  readonly isError: boolean;
}

/** Internal message representation stored in state.messages. */
export type AgentInternalMessage =
  | AgentInternalUserMessage
  | AgentInternalAssistantMessage
  | AgentInternalToolResultMessage;

export interface AgentInternalUserMessage {
  readonly role: 'user';
  readonly content: string;
  readonly timestamp: number;
}

export interface AgentInternalAssistantMessage {
  readonly role: 'assistant';
  readonly stopReason: 'tool_use' | 'end_turn' | 'error';
  readonly errorMessage?: string;
  readonly content: ReadonlyArray<Anthropic.ContentBlock>;
}

export interface AgentInternalToolResultMessage {
  readonly role: 'user';
  readonly content: ReadonlyArray<Anthropic.ToolResultBlockParam>;
}

/**
 * Observability callbacks for AgentLoop.
 *
 * All callbacks are optional and fire synchronously at specific lifecycle points.
 * Each is wrapped in try/catch inside AgentLoop to preserve the fire-and-forget
 * invariant: a throwing callback must never crash the agent loop.
 *
 * WHY callbacks instead of event emitter: AgentLoop is decoupled from
 * DaemonEventEmitter. Callbacks are the DI boundary that keeps AgentLoop
 * reusable outside the daemon without pulling in observability infrastructure.
 */
export interface AgentLoopCallbacks {
  /**
   * Called immediately before client.messages.create().
   * @param info.messageCount - Number of messages in the conversation at this point.
   */
  readonly onLlmTurnStarted?: (info: { readonly messageCount: number; readonly modelId: string }) => void;
  /**
   * Called when the stall timer fires: no LLM API call started within stallTimeoutMs.
   *
   * WHY a callback (not a return value): the timer fires asynchronously outside the
   * normal turn flow. The caller needs to set daemon-specific terminal state before
   * the loop exits. A callback keeps AgentLoop decoupled from daemon types while
   * giving the caller the signal it needs.
   *
   * WHY on AgentLoopCallbacks (not a separate option): callbacks is the established
   * extension channel for all AgentLoop lifecycle signals. Adding it here follows the
   * same pattern as onLlmTurnStarted, onToolCallStarted, etc.
   */
  readonly onStallDetected?: () => void;
  /**
   * Called immediately after client.messages.create() resolves successfully.
   * @param info.stopReason - The stop_reason from the API response.
   * @param info.outputTokens - Actual output token count from the API response.
   * @param info.inputTokens - Actual input token count from the API response.
   * @param info.toolNamesRequested - Names of tools the LLM requested (empty for end_turn).
   */
  readonly onLlmTurnCompleted?: (info: {
    readonly stopReason: string;
    readonly outputTokens: number;
    readonly inputTokens: number;
    readonly toolNamesRequested: readonly string[];
  }) => void;
  /**
   * Called immediately before tool.execute().
   * @param info.toolName - The tool's name.
   * @param info.argsSummary - JSON-serialized params, truncated to 200 chars.
   */
  readonly onToolCallStarted?: (info: { readonly toolName: string; readonly argsSummary: string }) => void;
  /**
   * Called immediately after a successful tool.execute().
   * @param info.toolName - The tool's name.
   * @param info.durationMs - Wall-clock duration of the tool execution in milliseconds.
   * @param info.resultSummary - First 200 chars of the tool result text content.
   */
  readonly onToolCallCompleted?: (info: { readonly toolName: string; readonly durationMs: number; readonly resultSummary: string }) => void;
  /**
   * Called when tool.execute() throws.
   * @param info.toolName - The tool's name.
   * @param info.durationMs - Wall-clock duration up to the point of failure.
   * @param info.errorMessage - First 200 chars of the error message.
   */
  readonly onToolCallFailed?: (info: { readonly toolName: string; readonly durationMs: number; readonly errorMessage: string }) => void;
}

/** Options for constructing an AgentLoop. */
export interface AgentLoopOptions {
  /** System prompt sent with every LLM request. */
  readonly systemPrompt: string;
  /** Tools available to the LLM. */
  readonly tools: readonly AgentTool[];
  /** Injectable LLM client (Anthropic direct or AnthropicBedrock). */
  readonly client: AgentClientInterface;
  /** Model ID to use (e.g. 'claude-sonnet-4-5' or 'us.anthropic.claude-sonnet-4-6'). */
  readonly modelId: string;
  /**
   * Maximum tokens in the LLM response.
   * Default: 8192 (sufficient for Claude Sonnet models).
   */
  readonly maxTokens?: number;
  /**
   * Tool execution strategy.
   * Only 'sequential' is needed for WorkRail (tools have ordering requirements).
   */
  readonly toolExecution?: 'sequential';
  /**
   * Optional observability callbacks for structured event emission.
   *
   * Each callback fires at a specific lifecycle point (before/after LLM call,
   * before/after tool execute). All are wrapped in try/catch -- a throwing callback
   * never crashes the agent loop. Callers that do not provide callbacks pay zero cost.
   *
   * WHY optional on the options object: keeps AgentLoopOptions self-contained and
   * follows the existing strategy-param pattern (toolExecution is already a strategy
   * field on options).
   */
  readonly callbacks?: AgentLoopCallbacks;
  /**
   * Maximum milliseconds between consecutive LLM API call starts before the loop
   * is considered stalled and aborted.
   *
   * The timer resets each time client.messages.create() is about to be called
   * (just before onLlmTurnStarted fires). If no new LLM call starts within this
   * window, the loop is stuck inside a tool execution (tool hung, network timeout,
   * file lock) and is aborted.
   *
   * When undefined (the default), stall detection is disabled.
   * Must be > 0 to enable -- values <= 0 are silently ignored.
   *
   * WHY injected here (not hardcoded): keeps AgentLoop decoupled from daemon-specific
   * defaults. The caller (workflow-runner.ts) is responsible for supplying the
   * correct timeout from trigger configuration.
   */
  readonly stallTimeoutMs?: number;
  /**
   * Maximum milliseconds a single client.messages.create() call may take before
   * the loop is aborted as a stall.
   *
   * The stall timer (stallTimeoutMs) fires when no new LLM call *starts* within
   * the configured window. This timer fires when an in-flight call does not
   * *return* within the configured window -- covering hung Bedrock/Anthropic calls
   * that start successfully but never resolve (network freeze, provider stall).
   *
   * When it fires, abort() + callbacks.onStallDetected() are called, same as the
   * stall timer. The result is WorkflowRunStuck { reason: 'stall' }.
   *
   * When undefined (the default), per-call timeout is disabled.
   * Must be > 0 to enable -- values <= 0 are silently ignored.
   *
   * WHY a separate field (not reusing stallTimeoutMs): the two timers have different
   * lifecycle ownership. stallTimeoutMs is a class-field timer cleared in prompt()'s
   * finally block. llmCallTimeoutMs is a local per-call timer cleared in the
   * try/finally wrapping each create() call. They must be named separately so the
   * AgentLoop can manage them independently.
   *
   * In practice, both are sourced from the same stallTimeoutSeconds config value
   * (see buildSessionContext()). One knob, two enforcement points.
   */
  readonly llmCallTimeoutMs?: number;
}

// ---------------------------------------------------------------------------
// AgentLoop
// ---------------------------------------------------------------------------

/**
 * Self-contained LLM agent loop.
 *
 * Replaces @mariozechner/pi-agent-core's Agent class with identical semantics
 * for the surface area used by workflow-runner.ts.
 */
export class AgentLoop {
  private readonly _options: AgentLoopOptions;
  private readonly _listeners: Array<(event: AgentEvent) => Promise<void> | void> = [];
  private readonly _steerQueue: Array<AgentInternalUserMessage> = [];
  private _messages: AgentInternalMessage[] = [];
  private _abortController: AbortController = new AbortController();
  private _isRunning = false;
  /**
   * Tracks whether abort() was called before or during a prompt() call.
   * WHY separate flag: prompt() resets the AbortController at startup.
   * If abort() was called BEFORE prompt(), we need to honor it without a
   * valid AbortController signal.
   */
  private _aborted = false;
  /**
   * Handle for the per-turn stall detection timer. Set just before each
   * client.messages.create() call; cleared when the next LLM call starts
   * (resetting the window) and in prompt()'s finally block (preventing a
   * post-completion fire). Undefined when stall detection is disabled or
   * no timer is currently active.
   */
  private _stallTimerHandle: ReturnType<typeof setTimeout> | undefined = undefined;

  constructor(options: AgentLoopOptions) {
    this._options = options;
  }

  /**
   * Subscribe to agent lifecycle events.
   *
   * Listeners are awaited in subscription order. Async listeners that call
   * steer() will have their message consumed in the current prompt() call.
   *
   * Returns an unsubscribe function.
   */
  subscribe(listener: (event: AgentEvent) => Promise<void> | void): () => void {
    this._listeners.push(listener);
    return () => {
      const idx = this._listeners.indexOf(listener);
      if (idx !== -1) this._listeners.splice(idx, 1);
    };
  }

  /**
   * Queue a message for injection after the current tool batch.
   *
   * WHY queue-based: steer() is called from a turn_end subscriber, which fires
   * after tool results are collected but before the next LLM call. The queue
   * is drained synchronously after all subscribers have been awaited.
   */
  steer(message: { role: 'user'; content: string; timestamp: number }): void {
    this._steerQueue.push({ role: 'user', content: message.content, timestamp: message.timestamp });
  }

  /**
   * Abort the current in-flight LLM call.
   *
   * WHY AbortController: the Anthropic SDK accepts an AbortSignal in request options.
   * Without this, abort() would only stop the loop from making another call --
   * the current in-flight call would run to completion.
   *
   * A new AbortController is created after each prompt() call so the loop
   * can be reused (though workflow-runner.ts creates a new AgentLoop per session).
   */
  abort(): void {
    this._aborted = true;
    this._abortController.abort();
  }

  /**
   * Notify the loop that forward progress is being made from outside the LLM call cycle.
   *
   * Resets the stall detection timer so long-running tool executions (e.g. spawn_agent
   * waiting on child sessions) do not trigger a false-positive stall abort. Should be
   * called whenever a delegated sub-task makes verifiable progress -- e.g. when a child
   * session advances a workflow step.
   *
   * WHY public (not just _resetStallTimer): this is a named capability -- "there is
   * activity happening in a delegated context" -- not an implementation detail. Callers
   * (tool factories) signal liveness; the internal mechanism is encapsulated.
   *
   * WHY for tools only: this is intended for delegation tools (spawn_agent) that run
   * sub-sessions. Direct tool calls that hang should be caught by the stall timer -- do
   * not call notifyActivity() as a general-purpose keepalive.
   */
  notifyActivity(): void {
    this._resetStallTimer();
  }

  /**
   * Reset the stall detection timer to its full window from now.
   *
   * Called in two places:
   * 1. At the top of _runLoop() before each LLM call (original behavior).
   * 2. In _executeTools() before each tool.execute() (C1: safety net for long tools).
   * 3. Via notifyActivity() when child session step advances are reported (C2: C2 progress).
   *
   * WHY a shared private method: avoids copy-pasting the setTimeout setup across 3 sites.
   */
  private _resetStallTimer(): void {
    const { callbacks, stallTimeoutMs } = this._options;
    if (stallTimeoutMs === undefined || stallTimeoutMs <= 0) return;
    if (this._stallTimerHandle !== undefined) {
      clearTimeout(this._stallTimerHandle);
    }
    this._stallTimerHandle = setTimeout(() => {
      if (!this._aborted) {
        this.abort();
        try { callbacks?.onStallDetected?.(); } catch { /* swallow */ }
      }
    }, stallTimeoutMs);
  }

  /**
   * Current agent state.
   *
   * state.messages is readable after prompt() resolves. workflow-runner.ts
   * reads state.messages to extract the last assistant message's stopReason
   * and errorMessage after the loop completes.
   */
  get state(): {
    readonly messages: ReadonlyArray<AgentInternalMessage>;
  } {
    return { messages: this._messages };
  }

  /**
   * Start the agent loop with the given initial user message.
   *
   * Resolves when the loop exits (end_turn + empty steer queue, error, or abort).
   * Does NOT throw on tool errors -- tool throws are caught and returned as isError
   * tool_results so the LLM can recover. Only LLM API errors (client.messages.create
   * failures) propagate as rejections.
   *
   * Loop algorithm:
   * 1. Append userMsg to messages
   * 2. Call client.messages.create() with AbortSignal
   * 3. Append assistant response to messages
   * 4. If tool_use: execute tools sequentially; unknown tools and throws get error tool_result
   * 5. Emit turn_end; await all subscribers (subscribers may call steer())
   * 6. If steer queue non-empty: pop, append, go to step 2
   * 7. If end_turn + empty steer queue: emit agent_end, exit
   * 8. If error or abort: append error message, emit agent_end, exit
   */
  async prompt(message: { role: 'user'; content: string; timestamp: number }): Promise<void> {
    // Reset abort controller for this prompt() call.
    // WHY: allows the same AgentLoop instance to be used for multiple prompts
    // (though workflow-runner.ts creates a new instance per session).
    // NOTE: if abort() was called before prompt(), _aborted flag is set and
    // the loop will exit immediately without making an API call.
    if (!this._aborted) {
      this._abortController = new AbortController();
    }
    this._isRunning = true;

    // Append the initial user message.
    this._messages.push({ role: 'user', content: message.content, timestamp: message.timestamp });

    try {
      await this._runLoop();
    } finally {
      this._isRunning = false;
      // Clear the stall timer on loop exit. WHY: the timer must be cancelled when
      // the loop exits cleanly (end_turn, abort, or API error) to prevent it from
      // firing after the loop has already completed and calling abort() again.
      // clearTimeout on undefined is a safe no-op.
      if (this._stallTimerHandle !== undefined) {
        clearTimeout(this._stallTimerHandle);
        this._stallTimerHandle = undefined;
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Private: core loop
  // ---------------------------------------------------------------------------

  private async _runLoop(): Promise<void> {
    const { client, modelId, systemPrompt, tools, maxTokens = 8192, callbacks, stallTimeoutMs, llmCallTimeoutMs } = this._options;

    while (true) {
      // Check abort before each LLM call.
      // WHY check both: _aborted covers pre-prompt abort; _abortController.signal
      // covers abort() called during an in-flight API call or between loop iterations.
      if (this._aborted || this._abortController.signal.aborted) {
        this._appendErrorMessage('aborted');
        await this._emitEvent({ type: 'agent_end' });
        return;
      }

      // Build the messages array for the API call.
      // Filter to only LLM-compatible messages (user and assistant).
      const apiMessages = this._buildApiMessages();

      // Build tool definitions for the API call.
      const apiTools: Anthropic.Tool[] = tools.map((t) => ({
        name: t.name,
        description: t.description,
        input_schema: t.inputSchema as Anthropic.Tool.InputSchema,
      }));

      // Reset the stall detection timer before each LLM call.
      // WHY here (before onLlmTurnStarted): this is the per-turn heartbeat point.
      // If no new LLM call starts within stallTimeoutMs, the loop is stuck inside
      // _executeTools() and should be aborted. _resetStallTimer() is also called
      // in _executeTools() before each tool.execute() (C1 safety net) and via
      // notifyActivity() when delegated sub-sessions report progress (C2).
      this._resetStallTimer();

      // Emit llm_turn_started before the API call.
      // WHY try/catch: preserves fire-and-forget invariant -- a throwing callback
      // must never crash the agent loop.
      try { callbacks?.onLlmTurnStarted?.({ messageCount: apiMessages.length, modelId }); } catch { /* swallow */ }

      // Per-call timeout: fire abort() if a single client.messages.create() call
      // does not return within llmCallTimeoutMs. Covers hung in-flight Bedrock/Anthropic
      // calls that the stall timer cannot detect (stall timer fires between calls, not
      // during a call). Fires the same abort() + onStallDetected() path as the stall timer.
      // WHY local variable (not class field): this timer is scoped to a single create()
      // call and cleared in the try/finally below. Class-field lifetime would be wrong.
      let perCallTimerHandle: ReturnType<typeof setTimeout> | undefined;
      if (llmCallTimeoutMs !== undefined && llmCallTimeoutMs > 0) {
        perCallTimerHandle = setTimeout(() => {
          // WHY _aborted guard: if the session was already aborted (SIGTERM, wall-clock,
          // stall timer) before this timer fires, do not overwrite the abort reason.
          if (!this._aborted) {
            this.abort();
            try { callbacks?.onStallDetected?.(); } catch { /* swallow */ }
          }
        }, llmCallTimeoutMs);
      }

      let response: Anthropic.Message;
      try {
        response = await client.messages.create(
          {
            model: modelId,
            system: systemPrompt,
            messages: apiMessages,
            tools: apiTools,
            max_tokens: maxTokens,
          },
          { signal: this._abortController.signal },
        );
      } catch (err: unknown) {
        // Distinguish abort from genuine API error.
        const isAbort =
          this._abortController.signal.aborted ||
          (err instanceof Error && err.name === 'AbortError');
        let message = err instanceof Error ? err.message : String(err);
        // WHY: a 400 from the API almost always means the model ID is wrong (bad inference
        // profile ID, missing -v1:0 suffix, etc.). Prepend context so the operator knows
        // exactly which field to fix rather than chasing a bare HTTP error code.
        // WHY duck-typed .status check (not instanceof APIError): agent-loop.ts only has
        // `import type` from @anthropic-ai/sdk -- no runtime SDK value imports. Duck-typing
        // is equally reliable since both sdk and bedrock-sdk always set .status on API errors.
        if (!isAbort && (err as { status?: number }).status === 400) {
          message = `agentConfig.model '${modelId}' was rejected by the API (check agentConfig.model in triggers.yml): ${message}`;
        }
        this._appendErrorMessage(isAbort ? 'aborted' : message);
        await this._emitEvent({ type: 'agent_end' });
        return;
      } finally {
        // Clear the per-call timer whether the call succeeded, was aborted, or errored.
        // WHY clearTimeout here (not after the try/catch): clearTimeout must run on every
        // exit path -- success, abort, and API error. A finally block is the only safe place.
        // WHY this is safe even if the timer already fired: clearTimeout on an already-fired
        // timer is a no-op. The _aborted guard in the timer callback prevents double-abort.
        if (perCallTimerHandle !== undefined) {
          clearTimeout(perCallTimerHandle);
          perCallTimerHandle = undefined;
        }
      }

      // Emit llm_turn_completed after the API response.
      // WHY try/catch: preserves fire-and-forget invariant.
      // WHY inline block: scopes toolNamesRequested to avoid polluting the outer loop.
      {
        const toolNamesRequested = response.content
          .filter((block): block is Anthropic.ToolUseBlock => block.type === 'tool_use')
          .map((block) => block.name);
        try {
          callbacks?.onLlmTurnCompleted?.({
            stopReason: response.stop_reason ?? 'unknown',
            outputTokens: response.usage.output_tokens,
            inputTokens: response.usage.input_tokens,
            toolNamesRequested,
          });
        } catch { /* swallow */ }
      }

      // Append the assistant response to messages.
      const stopReason = this._mapStopReason(response.stop_reason);
      const assistantMsg: AgentInternalAssistantMessage = {
        role: 'assistant',
        stopReason,
        content: response.content,
      };
      this._messages.push(assistantMsg);

      // Handle tool use.
      const toolUseBlocks = response.content.filter(
        (block): block is Anthropic.ToolUseBlock => block.type === 'tool_use',
      );

      if (stopReason === 'tool_use' || toolUseBlocks.length > 0) {
        const toolResults = await this._executeTools(toolUseBlocks);

        // Append tool results as a user message.
        const toolResultBlocks: Anthropic.ToolResultBlockParam[] = toolResults.map((r) => ({
          type: 'tool_result' as const,
          tool_use_id: r.toolCallId,
          content: r.result?.content.map((c) => ({ type: 'text' as const, text: c.text })) ?? [
            { type: 'text', text: r.isError ? `Tool error: ${r.toolName}` : '(no output)' },
          ],
          is_error: r.isError,
        }));
        this._messages.push({ role: 'user', content: toolResultBlocks });

        // Emit turn_end after tool results are appended.
        // WHY: subscribers (e.g., workflow-runner.ts) call steer() here to inject
        // the next workflow step BEFORE the next LLM call.
        await this._emitEvent({ type: 'turn_end', toolResults });

        // Drain steer queue: inject one message at a time before the next LLM call.
        const steered = this._drainSteerQueue();
        if (steered > 0) {
          // Continue loop -- steer messages were added, make another LLM call.
          continue;
        }

        // No steer messages -- continue the loop (LLM may have more tool calls).
        continue;
      }

      // No tool calls -- agent wants to stop.
      if (stopReason === 'end_turn') {
        // Emit turn_end with empty tool results (no tools were called this turn).
        await this._emitEvent({ type: 'turn_end', toolResults: [] });

        // Drain steer queue: if a subscriber added a steer message, continue.
        const steered = this._drainSteerQueue();
        if (steered > 0) {
          continue;
        }

        // Loop complete.
        await this._emitEvent({ type: 'agent_end' });
        return;
      }

      // Error or unknown stop reason.
      const errorMsg = (assistantMsg as AgentInternalAssistantMessage).errorMessage ?? `Unexpected stop_reason: ${response.stop_reason ?? 'unknown'}`;
      this._appendErrorMessage(errorMsg);
      await this._emitEvent({ type: 'agent_end' });
      return;
    }
  }

  // ---------------------------------------------------------------------------
  // Private: helpers
  // ---------------------------------------------------------------------------

  /**
   * Execute tool calls sequentially.
   *
   * WHY sequential: workflow tools have ordering requirements (continue_workflow
   * must complete before Bash begins on the next step).
   *
   * WHY error tool_result for unknown tools: LLMs occasionally hallucinate tool names.
   * Crashing the loop would lose all progress. An error tool_result lets the LLM
   * recover gracefully.
   */
  private async _executeTools(
    toolUseBlocks: readonly Anthropic.ToolUseBlock[],
  ): Promise<AgentToolCallResult[]> {
    const { callbacks } = this._options;
    const results: AgentToolCallResult[] = [];

    for (const block of toolUseBlocks) {
      // Check abort before each tool execution.
      if (this._abortController.signal.aborted) {
        results.push({
          toolCallId: block.id,
          toolName: block.name,
          result: null,
          isError: true,
        });
        continue;
      }

      const tool = this._options.tools.find((t) => t.name === block.name);
      if (!tool) {
        // Unknown tool name -- return error tool_result and continue.
        // WHY: LLMs occasionally hallucinate tool names. Crashing would lose all progress.
        results.push({
          toolCallId: block.id,
          toolName: block.name,
          result: {
            content: [{ type: 'text', text: `Unknown tool: ${block.name}` }],
            details: null,
          },
          isError: true,
        });
        continue;
      }

      // Execute the tool. Catch throws and return them as isError tool_results so the
      // LLM can see what went wrong and decide how to proceed.
      // WHY: killing the session on any tool failure loses all progress and prevents
      // the agent from recovering. A bash command exiting with code 1 is not a fatal
      // error -- the LLM must see stderr and decide whether to retry, rephrase, or
      // escalate. Same rationale as unknown tool names above.
      const params = (block.input ?? {}) as Record<string, unknown>;

      // Emit tool_call_started before execute().
      // WHY try/catch: preserves fire-and-forget invariant -- a throwing callback
      // must never crash the agent loop.
      const argsSummary = JSON.stringify(params).slice(0, 2000);
      try { callbacks?.onToolCallStarted?.({ toolName: block.name, argsSummary }); } catch { /* swallow */ }

      // C1: Reset stall timer before each tool execution.
      // WHY here: the stall timer fires when no new LLM call starts within stallTimeoutMs.
      // Without this reset, a legitimately long tool (e.g. spawn_agent running 18-min child
      // sessions) triggers a false-positive stall abort. Resetting here ensures the timer
      // measures 'time since last tool started' rather than 'time since last LLM call',
      // which correctly identifies genuine hangs (nothing started at all) vs. long but
      // productive tool executions.
      // WHY this is safe: a tool that starts then hangs forever still fires the stall at
      // stallTimeoutMs from its start -- the C2 path (notifyActivity on child step advances)
      // extends the window further for legitimately long delegated work.
      this._resetStallTimer();

      const toolStartMs = Date.now();
      let result: AgentToolResult<unknown>;
      try {
        result = await tool.execute(block.id, params, this._abortController.signal);
      } catch (err: unknown) {
        const durationMs = Date.now() - toolStartMs;
        const message = err instanceof Error ? err.message : String(err);
        // Emit tool_call_failed for the throwing path.
        try { callbacks?.onToolCallFailed?.({ toolName: block.name, durationMs, errorMessage: message.slice(0, 500) }); } catch { /* swallow */ }
        results.push({
          toolCallId: block.id,
          toolName: block.name,
          result: { content: [{ type: 'text', text: `Tool execution failed: ${message}` }], details: null },
          isError: true,
        });
        continue;
      }

      // Emit tool_call_completed for the success path.
      {
        const durationMs = Date.now() - toolStartMs;
        const resultSummary = (result.content[0]?.text ?? '(no output)').slice(0, 500);
        try { callbacks?.onToolCallCompleted?.({ toolName: block.name, durationMs, resultSummary }); } catch { /* swallow */ }
      }

      results.push({
        toolCallId: block.id,
        toolName: block.name,
        result,
        isError: false,
      });
    }

    return results;
  }

  /**
   * Drain the steer queue, appending each message to the conversation.
   * Returns the number of messages drained.
   */
  private _drainSteerQueue(): number {
    let count = 0;
    while (this._steerQueue.length > 0) {
      const msg = this._steerQueue.shift()!;
      this._messages.push(msg);
      count++;
    }
    return count;
  }

  /**
   * Emit an event to all subscribers in order.
   * All subscribers are awaited before returning.
   */
  private async _emitEvent(event: AgentEvent): Promise<void> {
    for (const listener of this._listeners) {
      await listener(event);
    }
  }

  /**
   * Append an assistant error message to state.messages.
   * Used when the loop exits due to abort or API error.
   */
  private _appendErrorMessage(errorMessage: string): void {
    this._messages.push({
      role: 'assistant',
      stopReason: 'error',
      errorMessage,
      content: [],
    });
  }

  /**
   * Convert the internal messages array to Anthropic API message format.
   *
   * The Anthropic API requires alternating user/assistant messages.
   * Internal messages use typed variants; the API needs MessageParam format.
   */
  private _buildApiMessages(): Anthropic.MessageParam[] {
    const result: Anthropic.MessageParam[] = [];

    for (const msg of this._messages) {
      if (msg.role === 'assistant') {
        const assistantMsg = msg as AgentInternalAssistantMessage;
        result.push({
          role: 'assistant',
          content: assistantMsg.content as Anthropic.ContentBlockParam[],
        });
      } else if (msg.role === 'user') {
        const userMsg = msg as AgentInternalUserMessage | AgentInternalToolResultMessage;
        if (typeof userMsg.content === 'string') {
          // Plain user message
          result.push({ role: 'user', content: (userMsg as AgentInternalUserMessage).content });
        } else {
          // Tool result message
          result.push({
            role: 'user',
            content: (userMsg as AgentInternalToolResultMessage).content as Anthropic.ContentBlockParam[],
          });
        }
      }
    }

    return result;
  }

  /**
   * Map Anthropic's stop_reason string to our internal stop reason type.
   */
  private _mapStopReason(
    stopReason: string | null | undefined,
  ): 'tool_use' | 'end_turn' | 'error' {
    switch (stopReason) {
      case 'tool_use':
        return 'tool_use';
      case 'end_turn':
        return 'end_turn';
      case 'max_tokens':
        // WHY end_turn: max_tokens means the model was truncated at the token limit,
        // not that an error occurred. Treating it as end_turn lets the loop continue
        // on the next turn so the agent can pick up where it left off.
        return 'end_turn';
      default:
        return 'error';
    }
  }
}
