/**
 * WorkRail Daemon: Structured Event Stream
 *
 * Appends structured JSON events to a daily JSONL file at
 * ~/.workrail/events/daemon/YYYY-MM-DD.jsonl.
 *
 * Design decisions:
 * - emit() is fire-and-forget (returns void synchronously). All async work runs
 *   in a detached Promise that swallows errors unconditionally. Observability
 *   must never affect correctness -- a failed append is always silent.
 * - File path is computed fresh from new Date() on each emit() call, so daily
 *   rotation happens automatically with zero state.
 * - Directory is created lazily on the first write (recursive mkdir is idempotent).
 * - DaemonEventEmitter is injected as an optional parameter wherever events are
 *   emitted (pattern mirrors DaemonRegistry in workflow-runner.ts). Callers that
 *   do not inject an emitter pay zero overhead.
 * - DaemonEvent is a discriminated union so invalid event shapes are impossible
 *   to construct at compile time.
 * - dirOverride is provided for testing: pass a temp directory to capture events
 *   without touching ~/.workrail.
 */

import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import * as os from 'node:os';

// ---------------------------------------------------------------------------
// RunId: branded process-local session UUID
// ---------------------------------------------------------------------------

/**
 * Branded type for the daemon's process-local session UUID.
 *
 * WHY branded: prevents accidental substitution with `workrailSessionId`
 * (the WorkRail engine `sess_*` ID) at call sites. Same pattern as TriggerId
 * in src/trigger/types.ts.
 *
 * Created exactly twice per session:
 * - `asRunId(randomUUID())` in workflow-runner.ts (normal path)
 * - `asRunId(entry.slice(0, -5))` in startup-recovery.ts (crash recovery)
 */
export type RunId = string & { readonly _brand: 'RunId' };

export function asRunId(value: string): RunId {
  return value as RunId;
}

// ---------------------------------------------------------------------------
// DaemonEvent: discriminated union of all event kinds
// ---------------------------------------------------------------------------

/** Daemon process started and webhook server is listening. */
export interface DaemonStartedEvent {
  readonly kind: 'daemon_started';
  readonly port: number;
  readonly workspacePath: string;
}

/** Incoming webhook accepted and validated. */
export interface TriggerFiredEvent {
  readonly kind: 'trigger_fired';
  readonly triggerId: string;
  readonly workflowId: string;
}

/** Workflow run entered the KeyedAsyncQueue (may wait for a slot). */
export interface SessionQueuedEvent {
  readonly kind: 'session_queued';
  readonly triggerId: string;
  readonly workflowId: string;
}

/** Workflow run started (session ID assigned, agent loop about to start). */
export interface SessionStartedEvent {
  readonly kind: 'session_started';
  readonly sessionId: RunId;
  readonly workflowId: string;
  readonly workspacePath: string;
  /**
   * The WorkRail session ID (e.g. 'sess_abc123') decoded from the continueToken.
   * Absent on the session_started event (emitted before executeStartWorkflow returns).
   * Present on subsequent per-session events once the continueToken is decoded.
   * Used by ConsoleService to correlate daemon event log entries with session store entries.
   */
  readonly workrailSessionId?: string;
}

/** An agent tool was called. */
export interface ToolCalledEvent {
  readonly kind: 'tool_called';
  readonly sessionId: RunId;
  readonly toolName: string;
  /** First 80 chars of the primary tool parameter (e.g. bash command, file path). */
  readonly summary?: string;
  /**
   * The WorkRail session ID (e.g. 'sess_abc123') for this tool call.
   * Used by ConsoleService to correlate daemon event log entries with session store entries.
   * Present when the continueToken was successfully decoded after executeStartWorkflow.
   */
  readonly workrailSessionId?: string;
}

/** A tool returned an error result (isError=true). */
export interface ToolErrorEvent {
  readonly kind: 'tool_error';
  readonly sessionId: RunId;
  readonly toolName: string;
  /** First 200 chars of the error message. */
  readonly error: string;
  /** The WorkRail session ID for correlation. Present when continueToken was decoded. */
  readonly workrailSessionId?: string;
}

/** Workflow advanced to the next step. */
export interface StepAdvancedEvent {
  readonly kind: 'step_advanced';
  readonly sessionId: RunId;
  /** The WorkRail session ID for correlation. Present when continueToken was decoded. */
  readonly workrailSessionId?: string;
  /**
   * The ID of the workflow step the agent was assigned NEXT after this advance.
   * Sourced from out.pending.stepId -- the step now pending in the engine after
   * the advance was applied. NOT the step that just completed.
   *
   * A correlation key -- maps this event to the workflow definition and session store.
   * Optional for backward compatibility with daemon logs written before this field existed.
   *
   * WHY stepId only (not stepTitle): stepId is a correlation key that belongs in the
   * daemon event log. stepTitle is human-readable content that lives authoritatively
   * in the workflow definition and session store -- duplicating it here would violate
   * single source of state truth.
   */
  readonly stepId?: string;
}

/** Workflow run ended (success, error, or timeout). */
export interface SessionCompletedEvent {
  readonly kind: 'session_completed';
  readonly sessionId: RunId;
  readonly workflowId: string;
  readonly outcome: 'success' | 'error' | 'timeout' | 'stuck' | 'gate_parked';
  /** Human-readable reason (stopReason, error message, or timeout type). */
  readonly detail?: string;
  /** The WorkRail session ID for correlation. Present when continueToken was decoded. */
  readonly workrailSessionId?: string;
}

/** HTTP POST to callbackUrl was attempted. */
export interface DeliveryAttemptedEvent {
  readonly kind: 'delivery_attempted';
  readonly callbackUrl: string;
  readonly outcome: 'success' | 'http_error' | 'network_error';
  readonly statusCode?: number;
}

/**
 * An agent called report_issue to record a structured issue for the auto-fix coordinator.
 *
 * WHY issueKind not kind: `kind` is the union discriminant ('issue_reported'); the
 * payload field that describes the category of the reported issue is named `issueKind`
 * to avoid shadowing the discriminant in the interface.
 */
export interface IssueReportedEvent {
  readonly kind: 'issue_reported';
  readonly sessionId: RunId;
  readonly issueKind: 'tool_failure' | 'blocked' | 'unexpected_behavior' | 'needs_human' | 'self_correction';
  readonly severity: 'info' | 'warn' | 'error' | 'fatal';
  readonly summary: string;
  /** Current continueToken, if the agent provided it (enables coordinator resumption). */
  readonly continueToken?: string;
  /** The WorkRail session ID for correlation. Present when continueToken was decoded. */
  readonly workrailSessionId?: string;
}

/**
 * LLM turn starting: the agent is about to call the LLM API.
 *
 * Emitted in agent-loop.ts immediately before client.messages.create().
 * WHY messageCount: the number of messages in the conversation is a proxy for
 * input token usage. Actual input tokens are not available until the API responds.
 */
export interface LlmTurnStartedEvent {
  readonly kind: 'llm_turn_started';
  readonly sessionId: RunId;
  /** Number of messages in the conversation at the time of the call. */
  readonly messageCount: number;
  /** The model ID used for this LLM turn (e.g. 'claude-sonnet-4-5'). */
  readonly modelId?: string;
  /** The WorkRail session ID for correlation. Present when continueToken was decoded. */
  readonly workrailSessionId?: string;
}

/**
 * LLM turn completed: the LLM API returned a response.
 *
 * Emitted in agent-loop.ts immediately after client.messages.create() resolves.
 * WHY actual tokens: response.usage contains the exact counts from the API.
 */
export interface LlmTurnCompletedEvent {
  readonly kind: 'llm_turn_completed';
  readonly sessionId: RunId;
  /** The stop_reason from the API response ('tool_use', 'end_turn', etc.). */
  readonly stopReason: string;
  /** Actual output token count from the API response. */
  readonly outputTokens: number;
  /** Actual input token count from the API response. */
  readonly inputTokens: number;
  /** Names of tools the LLM requested in this turn (empty if end_turn). */
  readonly toolNamesRequested: readonly string[];
  /** The WorkRail session ID for correlation. Present when continueToken was decoded. */
  readonly workrailSessionId?: string;
}

/**
 * A tool call is starting. Emitted in agent-loop.ts before tool.execute().
 *
 * NOTE -- dual-stream model:
 * Two parallel tool event streams exist in the daemon JSONL log:
 *
 * 1. COARSE stream (legacy): `tool_called` events emitted from inside each
 *    tool's execute() body in workflow-runner.ts. Includes a tool-specific
 *    `summary` field (truncated command/path). Consumed by `readLiveActivity()`
 *    in console-service.ts for the live session panel.
 *
 * 2. FINE-GRAINED stream (new): `tool_call_started`, `tool_call_completed`,
 *    `tool_call_failed` events emitted via AgentLoopCallbacks in agent-loop.ts.
 *    Includes `durationMs` and `resultSummary`. Intended for timing analysis,
 *    `worktrain logs --follow`, and future analytics features.
 *
 * WHY two streams: `tool_called` predates AgentLoopCallbacks and is emitted
 * from inside each tool -- it has tool-specific context (the Bash command, the
 * file path) that AgentLoop cannot see. The fine-grained stream adds timing
 * and lifecycle without replacing the coarse stream.
 *
 * WHY argsSummary: raw params may be large (e.g. file contents in Write tool).
 * Truncating to 200 chars gives observability without bloating the event log.
 */
export interface ToolCallStartedEvent {
  readonly kind: 'tool_call_started';
  readonly sessionId: RunId;
  readonly toolName: string;
  /** JSON-serialized params, truncated to 200 chars. */
  readonly argsSummary: string;
  /** The WorkRail session ID for correlation. Present when continueToken was decoded. */
  readonly workrailSessionId?: string;
}

/**
 * A tool call completed successfully. Emitted in agent-loop.ts after tool.execute().
 */
export interface ToolCallCompletedEvent {
  readonly kind: 'tool_call_completed';
  readonly sessionId: RunId;
  readonly toolName: string;
  /** Wall-clock duration of the tool execution in milliseconds. */
  readonly durationMs: number;
  /** First 200 chars of the tool result text content. */
  readonly resultSummary: string;
  /** The WorkRail session ID for correlation. Present when continueToken was decoded. */
  readonly workrailSessionId?: string;
}

/**
 * A tool call failed (tool.execute() threw). Emitted in agent-loop.ts in the catch block.
 *
 * WHY separate from tool_error: tool_error is emitted by the turn_end subscriber in
 * workflow-runner.ts for isError tool_results. tool_call_failed is emitted by the
 * agent-loop.ts catch block when execute() throws -- finer-grained timing.
 */
export interface ToolCallFailedEvent {
  readonly kind: 'tool_call_failed';
  readonly sessionId: RunId;
  readonly toolName: string;
  /** Wall-clock duration up to the point of failure in milliseconds. */
  readonly durationMs: number;
  /** First 200 chars of the error message. */
  readonly errorMessage: string;
  /** The WorkRail session ID for correlation. Present when continueToken was decoded. */
  readonly workrailSessionId?: string;
}

/** Daemon process stopped cleanly (SIGTERM/SIGINT) or crashed (uncaught exception). */
export interface DaemonStoppedEvent {
  readonly kind: 'daemon_stopped';
  readonly reason: 'graceful' | 'crash';
  readonly ts: number;
}

/**
 * A workflow session was aborted because the daemon was stopped before the session completed.
 *
 * WHY: When the daemon receives SIGTERM/SIGINT, in-flight sessions are killed without
 * completing. Without this event, the JSONL event log shows them as RUNNING forever,
 * making `worktrain health` and `worktrain status` untrustworthy after a restart.
 * Emitting this event at shutdown gives consumers a definitive terminal state.
 *
 * WHY reason is a closed union: make illegal states unrepresentable. 'daemon_shutdown'
 * is graceful termination (SIGTERM/SIGINT); 'daemon_killed' is reserved for forceful
 * termination (SIGKILL or OOM). Only 'daemon_shutdown' is emitted today.
 *
 * WHY sessionId = workrailSessionId: at shutdown time, the only available in-process
 * session identifier is the workrailSessionId from the steerRegistry. The process-local
 * UUID is not accessible at this boundary. Log consumers filter by either field, so this
 * does not affect filtering correctness.
 */
export interface DaemonSessionAbortedEvent {
  readonly kind: 'session_aborted';
  /**
   * The workrailSessionId (sess_* ID) used as the session identifier here.
   * At shutdown time the process-local RunId is not available -- only the
   * workrailSessionId from ActiveSessionSet is accessible.
   * WHY string (not RunId): this field carries a workrailSessionId, not a RunId.
   */
  readonly sessionId: string;
  readonly workrailSessionId?: string;
  readonly reason: 'daemon_shutdown' | 'daemon_killed';
  readonly ts: number;
}

/** Periodic heartbeat confirming the daemon is still alive. */
export interface DaemonHeartbeatEvent {
  readonly kind: 'daemon_heartbeat';
  readonly activeSessions: number;
  readonly ts: number;
}

/**
 * A dispatch was rejected because the per-trigger serialization queue was at capacity.
 *
 * WHY: emitted on every HTTP 429 rejection so operators can observe backpressure events
 * in the daemon event log. This is the daemon-side counterpart to the HTTP 429 response --
 * the HTTP layer tells the caller, this event records the rejection in the event log.
 *
 * WHY reason is a closed union: make illegal states unrepresentable. Only 'queue_full'
 * is possible today; future rejection reasons (e.g. 'trigger_paused') can be added here.
 */
export interface SessionDroppedEvent {
  readonly kind: 'session_dropped';
  readonly triggerId: string;
  readonly workflowId: string;
  readonly reason: 'queue_full';
  readonly queueDepth: number;
  readonly maxQueueDepth: number;
}

/**
 * Emitted when the agent calls signal_coordinator to record a coordinator signal.
 *
 * WHY a separate event kind: coordinator signals are categorically different from
 * tool calls, issues, or step advances. They are the agent-to-coordinator channel
 * defined in docs/discovery/mid-session-coordinator-signaling.md (Phase 1 -- A).
 * A distinct event kind lets the console, coordinator scripts, and `worktrain logs`
 * filter and act on signals without parsing generic tool_called events.
 *
 * WHY signalKind is a string (not a closed enum here): the event layer mirrors the
 * CoordinatorSignalKindSchema values from the artifact schema. Keeping it as a string
 * avoids a cross-module enum import in daemon-events.ts. Consumers that need a closed
 * enum should import CoordinatorSignalKindSchema from the artifact schema module.
 */
export interface SignalEmittedEvent {
  readonly kind: 'signal_emitted';
  readonly sessionId: RunId;
  /**
   * The signal kind ('progress' | 'finding' | 'data_needed' | 'approval_needed' | 'blocked').
   * Matches the CoordinatorSignalKind values from coordinator-signal.ts.
   */
  readonly signalKind: string;
  /** Short unique identifier for this signal (sig_<8 hex chars>). */
  readonly signalId: string;
  /** The payload provided by the agent (arbitrary key-value pairs). */
  readonly payload: Readonly<Record<string, unknown>>;
  /** The WorkRail session ID for correlation. Present when continueToken was decoded. */
  readonly workrailSessionId?: string;
}

/**
 * Emitted when the stuck-detection heuristics in workflow-runner.ts identify that
 * the agent is likely stuck and not making forward progress.
 *
 * WHY a separate event kind: stuck is categorically different from a tool failure.
 * It is a higher-level signal that the agent has entered a loop or is blocked
 * on a gate it cannot pass. Callers (console, coordinator scripts, worktrain logs)
 * need to distinguish "this tool call failed once" from "the agent is not progressing".
 *
 * WHY reason is a closed union: illegal states must be unrepresentable. A freeform
 * string for reason would require string parsing at every consumer.
 *
 * WHY advisory only: this event does NOT abort the session. It is purely observational.
 * The fire-and-forget emitter contract means stuck detection never affects correctness.
 */
export interface AgentStuckEvent {
  readonly kind: 'agent_stuck';
  readonly sessionId: RunId;
  /**
   * Which heuristic triggered:
   * - repeated_tool_call: same tool + same args called 3+ times in a row
   * - no_progress: 80%+ of turns used with 0 step advances
   * - timeout_imminent: wall-clock timeout fired (session already aborting)
   * - stall: no LLM API call started within stallTimeoutSeconds (default 120s);
   *   the loop was stuck inside a tool execution that never completed
   */
  readonly reason: 'repeated_tool_call' | 'no_progress' | 'timeout_imminent' | 'stall';
  /** Human-readable description of why stuck was detected. */
  readonly detail: string;
  /** The tool name that was called repeatedly (present for repeated_tool_call). */
  readonly toolName?: string;
  /** The argsSummary of the repeated call (present for repeated_tool_call). */
  readonly argsSummary?: string;
  /** The WorkRail session ID for correlation. Present when continueToken was decoded. */
  readonly workrailSessionId?: string;
}

/**
 * Union of all daemon lifecycle events.
 *
 * Each member has a `kind` discriminant so switch exhaustiveness is enforced
 * by the TypeScript compiler.
 */
/** Delivery planned at session start -- records which adapters will be used. */
export interface DeliveryPlannedEvent {
  readonly kind: 'delivery_planned';
  readonly sessionId: RunId;
  /** Adapter kinds resolved for this session. Absent when deliveryConfig is not set. */
  readonly deliveryAdapterKinds?: readonly import('../trigger/delivery-adapter.js').AdapterConfig['kind'][];
  readonly workrailSessionId?: string;
}

export type DaemonEvent =
  | DaemonStartedEvent
  | DaemonStoppedEvent
  | DaemonHeartbeatEvent
  | TriggerFiredEvent
  | SessionQueuedEvent
  | SessionStartedEvent
  | SessionDroppedEvent
  | ToolCalledEvent
  | ToolErrorEvent
  | StepAdvancedEvent
  | SessionCompletedEvent
  | DaemonSessionAbortedEvent
  | DeliveryAttemptedEvent
  | IssueReportedEvent
  | LlmTurnStartedEvent
  | LlmTurnCompletedEvent
  | ToolCallStartedEvent
  | ToolCallCompletedEvent
  | ToolCallFailedEvent
  | AgentStuckEvent
  | SignalEmittedEvent
  | DeliveryPlannedEvent;

// ---------------------------------------------------------------------------
// DaemonEventEmitter
// ---------------------------------------------------------------------------

/**
 * Append-only event emitter for the WorkRail daemon.
 *
 * Each call to emit() writes one JSON line to the daily file:
 *   ~/.workrail/events/daemon/YYYY-MM-DD.jsonl
 * (or dirOverride/YYYY-MM-DD.jsonl in tests).
 *
 * The emitter is injected as an optional parameter wherever events are emitted.
 * Callers that do not inject an instance pay zero cost.
 */
export class DaemonEventEmitter {
  private readonly _dir: string;
  private _tail: Promise<void> = Promise.resolve();

  constructor(dirOverride?: string) {
    this._dir = dirOverride ?? path.join(os.homedir(), '.workrail', 'events', 'daemon');
  }

  emit(event: DaemonEvent): void {
    // Chaining serializes writes FIFO; .catch() isolates failures so a bad write
    // never blocks subsequent emits.
    this._tail = this._tail.then(() => this._append(event)).catch(() => {});
  }

  private async _append(event: DaemonEvent): Promise<void> {
    const date = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
    const filePath = path.join(this._dir, `${date}.jsonl`);
    await fs.mkdir(this._dir, { recursive: true });
    const line = JSON.stringify({ ...event, ts: Date.now() }) + '\n';
    await fs.appendFile(filePath, line, 'utf8');
  }
}

